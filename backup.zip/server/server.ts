import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import swaggerUi from 'swagger-ui-express';
import { productService, planService, companyService, userService, licenseService, deviceService, invoiceService, activityLogService, bankService, roleService, menuService, rolePermissionService } from './services';
import { generateToken, verifyToken } from '../lib/auth/jwt';
import jwt from 'jsonwebtoken';

// Swagger setup
const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'License Management Dashboard API',
      version: '1.0.0',
      description: 'API for managing software licenses, products, plans, invoices, and more',
    },
    servers: [
      {
        url: `http://${process.env.BACKEND_HOST || 'localhost'}:${process.env.PORT || '5000'}`,
        description: 'Development server'
      }
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT'
        }
      }
    },
    security: [
      {
        bearerAuth: []
      }
    ],
    tags: [
      {
        name: 'Products',
        description: 'Operations related to products'
      },
      {
        name: 'Plans',
        description: 'Operations related to plans'
      },
      {
        name: 'Companies',
        description: 'Operations related to companies'
      },
      {
        name: 'Users',
        description: 'Operations related to users'
      },
      {
        name: 'Licenses',
        description: 'Operations related to licenses'
      },
      {
        name: 'Devices',
        description: 'Operations related to devices'
      },
      {
        name: 'Invoices',
        description: 'Operations related to invoices'
      },
      {
        name: 'Banks',
        description: 'Operations related to banks'
      },
      {
        name: 'Activity Logs',
        description: 'Operations related to activity logs'
      },
      {
        name: 'Banks',
        description: 'Operations related to banks'
      }
    ]
  },
  apis: ['./server/server.ts'], // Path to the API docs
};

import swaggerJsdoc from 'swagger-jsdoc';
const specs = swaggerJsdoc(options);

const app = express();
const PORT = parseInt(process.env.PORT || '5000');
const BACKEND_HOST = process.env.BACKEND_HOST || 'localhost';

// JWT Authentication Middleware
import { authenticateJWT } from '../lib/auth/jwt';

// Public endpoints that don't require authentication
const publicEndpoints = [
  '/api-docs', 
  '/api-docs/', 
  '/', // Root path should only match exact root, not all paths
  '/api/auth/login',
  '/api/auth/register',
  '/api/auth/refresh'
];

const isPublicEndpoint = (path: string): boolean => {
  console.log('Checking if path is public:', path);
  const isPublic = publicEndpoints.some(endpoint => {
    // Special handling for root path to match exactly, not as a prefix
    if (endpoint === '/') {
      return path === '/';
    }
    const match = path.startsWith(endpoint);
    console.log(`  ${path} starts with ${endpoint}: ${match}`);
    return match;
  });
  console.log('Result for', path, ':', isPublic);
  return isPublic;
};

// Middleware
app.use(cors());
app.use(express.json());

// Apply JWT authentication middleware to all routes except public endpoints
app.use((req: Request, res: Response, next: NextFunction) => {
  console.log('GLOBAL MIDDLEWARE - Request method:', req.method, 'path:', req.path);
  
  // Skip JWT auth for public endpoints
  if (isPublicEndpoint(req.path)) {
    console.log('Skipping JWT auth for public endpoint:', req.path);
    return next();
  }
  
  // Apply JWT authentication for all other endpoints
  console.log('Applying JWT auth for protected endpoint:', req.path);
  authenticateJWT(req, res, next);
});

// Authentication endpoints
/** 
 * @swagger
 * /api/auth/login:
 *   post:
 *     summary: Log in a user
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email:
 *                 type: string
 *                 example: admin@gmail.com
 *               password:
 *                 type: string
 *                 example: admin123
 *     responses:
 *       200:
 *         description: Login successful
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 accessToken:
 *                   type: string
 *                 refreshToken:
 *                   type: string
 *                 user:
 *                   $ref: '#/components/schemas/User'
 *       400:
 *         description: Bad request
 *       401:
 *         description: Invalid credentials
 */
app.post('/api/auth/login', async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    // Find user by email
    const user = await userService.getByEmail(email);
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Simple password check (hardcoded for demo purposes)
    let isValidPassword = false;
    
    if (user.email === 'admin@gmail.com') {
      isValidPassword = password === 'admin123';
    } else {
      // For non-admin users, just accept any password for demo
      isValidPassword = true;
    }
    
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Generate tokens
    const accessToken = generateToken({
      userId: user.id,
      email: user.email,
      role: user.role
    });

    // Generate refresh token
    const refreshTokenSecret = process.env.REFRESH_TOKEN_SECRET || 'fallback-refresh-secret-change-in-production';
    const refreshToken = jwt.sign(
      { userId: user.id, email: user.email },
      refreshTokenSecret,
      { expiresIn: process.env.REFRESH_TOKEN_EXPIRES_IN || '7d' }
    );

    // Store refresh token in user (in a real app, store in DB or cache)
    // For demo, we'll just send it to the client

    res.json({
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

/** 
 * @swagger
 * /api/auth/refresh:
 *   post:
 *     summary: Refresh access token
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               refreshToken:
 *                 type: string
 *     responses:
 *       200:
 *         description: Token refreshed successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 accessToken:
 *                   type: string
 *       400:
 *         description: Bad request
 *       401:
 *         description: Invalid refresh token
 */
app.post('/api/auth/refresh', async (req: Request, res: Response) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(400).json({ error: 'Refresh token is required' });
    }

    const refreshTokenSecret = process.env.REFRESH_TOKEN_SECRET || 'fallback-refresh-secret-change-in-production';
    
    try {
      const decoded = jwt.verify(refreshToken, refreshTokenSecret) as { userId: string; email: string };
      
      // Get user to verify they still exist
      const user = await userService.getById(decoded.userId);
      if (!user) {
        return res.status(401).json({ error: 'Invalid refresh token' });
      }

      // Generate new access token
      const accessToken = generateToken({
        userId: user.id,
        email: user.email,
        role: user.role
      });

      res.json({ accessToken });
    } catch (error) {
      return res.status(401).json({ error: 'Invalid refresh token' });
    }
  } catch (error) {
    console.error('Refresh token error:', error);
    res.status(500).json({ error: 'Token refresh failed' });
  }
});

/** 
 * @swagger
 * /api/auth/logout:
 *   post:
 *     summary: Log out a user
 *     tags: [Auth]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: false
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               refreshToken:
 *                 type: string
 *     responses:
 *       200:
 *         description: Logout successful
 *       401:
 *         description: Unauthorized
 */
app.post('/api/auth/logout', (req: Request, res: Response) => {
  try {
    // In a real app, you would invalidate the refresh token
    // For demo, we'll just return success
    
    res.json({ message: 'Logout successful' });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ error: 'Logout failed' });
  }
});

/** 
 * @swagger
 * /api/auth/register:
 *   post:
 *     summary: Register a new user
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: John Doe
 *               email:
 *                 type: string
 *                 example: johndoe@example.com
 *               password:
 *                 type: string
 *                 example: securepassword123
 *     responses:
 *       201:
 *         description: User registered successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 accessToken:
 *                   type: string
 *                 refreshToken:
 *                   type: string
 *                 user:
 *                   $ref: '#/components/schemas/User'
 *       400:
 *         description: Bad request
 *       409:
 *         description: User already exists
 */
app.post('/api/auth/register', async (req: Request, res: Response) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email, and password are required' });
    }

    // Check if user already exists
    try {
      const existingUser = await userService.getByEmail(email);
      if (existingUser) {
        return res.status(409).json({ error: 'User with this email already exists' });
      }
    } catch (error) {
      // User doesn't exist, continue with registration
    }

    // Get the first company to assign the user to (as a default)
    const companies = await companyService.getAll();
    if (companies.length === 0) {
      return res.status(400).json({ error: 'Cannot register a new user: No companies exist in the system.' });
    }

    // Create the new user (password is not stored in the user table for demo purposes)
    const newUser = await userService.create({
      name,
      email,
      role: 'User', // Default role for new users
      companyId: companies[0].id // Assign to first company
    });

    // Generate tokens for the newly registered user
    const accessToken = generateToken({
      userId: newUser.id,
      email: newUser.email,
      role: newUser.role
    });

    const refreshTokenSecret = process.env.REFRESH_TOKEN_SECRET || 'fallback-refresh-secret-change-in-production';
    const refreshToken = jwt.sign(
      { userId: newUser.id, email: newUser.email },
      refreshTokenSecret,
      { expiresIn: process.env.REFRESH_TOKEN_EXPIRES_IN || '7d' }
    );

    res.status(201).json({
      accessToken,
      refreshToken,
      user: {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Registration failed' });
  }
});

/** 
 * @swagger
 * /api/auth/me:
 *   get:
 *     summary: Get current user profile
 *     tags: [Auth]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: User profile retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 *       401:
 *         description: Unauthorized
 */
app.get('/api/auth/me', async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    // Get full user info from database
    const fullUser = await userService.getById(user.userId);
    if (!fullUser) {
      return res.status(401).json({ error: 'User not found' });
    }

    res.json({
      id: fullUser.id,
      name: fullUser.name,
      email: fullUser.email,
      role: fullUser.role
    });
  } catch (error) {
    console.error('Get user profile error:', error);
    res.status(500).json({ error: 'Failed to retrieve user profile' });
  }
});

// Error handling middleware

// Swagger UI
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(specs));

// API routes for products
/**
 * @swagger
 * /api/products:
 *   get:
 *     summary: Get all products
 *     tags: [Products]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of products
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   name:
 *                     type: string
 *                   description:
 *                     type: string
 */
app.get('/api/products', async (req: Request, res: Response) => {
  try {
    const products = await productService.getAll();
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

/**
 * @swagger
 * /api/products/{id}:
 *   get:
 *     summary: Get a product by ID
 *     tags: [Products]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The product ID
 *     responses:
 *       200:
 *         description: A single product
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 description:
 *                   type: string
 *       404:
 *         description: Product not found
 */
app.get('/api/products/:id', async (req: Request, res: Response) => {
  try {
    const product = await productService.getById(req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.json(product);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch product' });
  }
});

/**
 * @swagger
 * /api/products:
 *   post:
 *     summary: Create a new product
 *     tags: [Products]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               description:
 *                 type: string
 *     responses:
 *       201:
 *         description: Created product
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 description:
 *                   type: string
 */
app.post('/api/products', async (req: Request, res: Response) => {
  try {
    const product = await productService.create(req.body);
    res.status(201).json(product);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create product' });
  }
});

/**
 * @swagger
 * /api/products/{id}:
 *   put:
 *     summary: Update a product
 *     tags: [Products]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The product ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               description:
 *                 type: string
 *     responses:
 *       200:
 *         description: Updated product
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 description:
 *                   type: string
 */
app.put('/api/products/:id', async (req: Request, res: Response) => {
  try {
    const product = await productService.update(req.params.id, req.body);
    res.json(product);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update product' });
  }
});

/**
 * @swagger
 * /api/products/{id}:
 *   delete:
 *     summary: Delete a product
 *     tags: [Products]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The product ID
 *     responses:
 *       204:
 *         description: Product deleted successfully
 */
app.delete('/api/products/:id', async (req: Request, res: Response) => {
  try {
    await productService.delete(req.params.id);
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete product' });
  }
});

// API routes for plans
/**
 * @swagger
 * /api/plans:
 *   get:
 *     summary: Get all plans
 *     tags: [Plans]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of plans
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   productId:
 *                     type: string
 *                   name:
 *                     type: string
 *                   price:
 *                     type: number
 *                   deviceLimit:
 *                     type: number
 *                   durationDays:
 *                     type: number
 */
app.get('/api/plans', async (req: Request, res: Response) => {
  try {
    const plans = await planService.getAll();
    res.json(plans);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch plans' });
  }
});

/**
 * @swagger
 * /api/plans/{id}:
 *   get:
 *     summary: Get a plan by ID
 *     tags: [Plans]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The plan ID
 *     responses:
 *       200:
 *         description: A single plan
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 productId:
 *                   type: string
 *                 name:
 *                   type: string
 *                 price:
 *                   type: number
 *                 deviceLimit:
 *                   type: number
 *                 durationDays:
 *                   type: number
 *       404:
 *         description: Plan not found
 */
app.get('/api/plans/:id', async (req: Request, res: Response) => {
  try {
    const plan = await planService.getById(req.params.id);
    if (!plan) {
      return res.status(404).json({ error: 'Plan not found' });
    }
    res.json(plan);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch plan' });
  }
});

/**
 * @swagger
 * /api/plans:
 *   post:
 *     summary: Create a new plan
 *     tags: [Plans]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               productId:
 *                 type: string
 *               name:
 *                 type: string
 *               price:
 *                 type: number
 *               deviceLimit:
 *                 type: number
 *               durationDays:
 *                 type: number
 *     responses:
 *       201:
 *         description: Created plan
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 productId:
 *                   type: string
 *                 name:
 *                   type: string
 *                 price:
 *                   type: number
 *                 deviceLimit:
 *                   type: number
 *                 durationDays:
 *                   type: number
 */
app.post('/api/plans', async (req: Request, res: Response) => {
  try {
    const plan = await planService.create(req.body);
    res.status(201).json(plan);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create plan' });
  }
});

/**
 * @swagger
 * /api/plans/{id}:
 *   put:
 *     summary: Update a plan
 *     tags: [Plans]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The plan ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               price:
 *                 type: number
 *               deviceLimit:
 *                 type: number
 *               durationDays:
 *                 type: number
 *     responses:
 *       200:
 *         description: Updated plan
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 productId:
 *                   type: string
 *                 name:
 *                   type: string
 *                 price:
 *                   type: number
 *                 deviceLimit:
 *                   type: number
 *                 durationDays:
 *                   type: number
 */
app.put('/api/plans/:id', async (req: Request, res: Response) => {
  try {
    const plan = await planService.update(req.params.id, req.body);
    res.json(plan);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update plan' });
  }
});

/**
 * @swagger
 * /api/plans/{id}:
 *   delete:
 *     summary: Delete a plan
 *     tags: [Plans]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The plan ID
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       204:
 *         description: Plan deleted successfully
 */
app.delete('/api/plans/:id', async (req: Request, res: Response) => {
  try {
    await planService.delete(req.params.id);
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete plan' });
  }
});

// API routes for companies
/**
 * @swagger
 * /api/companies:
 *   get:
 *     summary: Get all companies
 *     tags: [Companies]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of companies
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   name:
 *                     type: string
 *                   createdAt:
 *                     type: string
 */
app.get('/api/companies', async (req: Request, res: Response) => {
  try {
    const companies = await companyService.getAll();
    res.json(companies);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch companies' });
  }
});

/**
 * @swagger
 * /api/companies/{id}:
 *   get:
 *     summary: Get a company by ID
 *     tags: [Companies]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The company ID
 *     responses:
 *       200:
 *         description: A single company
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 createdAt:
 *                   type: string
 *       404:
 *         description: Company not found
 */
app.get('/api/companies/:id', async (req: Request, res: Response) => {
  try {
    const company = await companyService.getById(req.params.id);
    if (!company) {
      return res.status(404).json({ error: 'Company not found' });
    }
    res.json(company);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch company' });
  }
});

/**
 * @swagger
 * /api/companies:
 *   post:
 *     summary: Create a new company
 *     tags: [Companies]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *     responses:
 *       201:
 *         description: Created company
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 createdAt:
 *                   type: string
 */
app.post('/api/companies', async (req: Request, res: Response) => {
  try {
    const company = await companyService.create(req.body);
    res.status(201).json(company);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create company' });
  }
});

/**
 * @swagger
 * /api/companies/{id}:
 *   put:
 *     summary: Update a company
 *     tags: [Companies]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The company ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *     responses:
 *       200:
 *         description: Updated company
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 createdAt:
 *                   type: string
 */
app.put('/api/companies/:id', async (req: Request, res: Response) => {
  try {
    const company = await companyService.update(req.params.id, req.body);
    res.json(company);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update company' });
  }
});

/**
 * @swagger
 * /api/companies/{id}:
 *   delete:
 *     summary: Delete a company
 *     tags: [Companies]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The company ID
 *     responses:
 *       204:
 *         description: Company deleted successfully
 */
app.delete('/api/companies/:id', async (req: Request, res: Response) => {
  try {
    await companyService.delete(req.params.id);
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete company' });
  }
});

// API routes for users
/**
 * @swagger
 * /api/users:
 *   get:
 *     summary: Get all users
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of users
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   name:
 *                     type: string
 *                   email:
 *                     type: string
 *                   role:
 *                     type: string
 *                   companyId:
 *                     type: string
 *                   createdAt:
 *                     type: string
 */
app.get('/api/users', async (req: Request, res: Response) => {
  try {
    const users = await userService.getAll();
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

/**
 * @swagger
 * /api/users/{id}:
 *   get:
 *     summary: Get a user by ID
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The user ID
 *     responses:
 *       200:
 *         description: A single user
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 email:
 *                   type: string
 *                 role:
 *                   type: string
 *                 companyId:
 *                   type: string
 *                 createdAt:
 *                   type: string
 *       404:
 *         description: User not found
 */
app.get('/api/users/:id', async (req: Request, res: Response) => {
  try {
    const user = await userService.getById(req.params.id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch user' });
  }
});

/**
 * @swagger
 * /api/users:
 *   post:
 *     summary: Create a new user
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               email:
 *                 type: string
 *               role:
 *                 type: string
 *               companyId:
 *                 type: string
 *     responses:
 *       201:
 *         description: Created user
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 email:
 *                   type: string
 *                 role:
 *                   type: string
 *                 companyId:
 *                   type: string
 *                 createdAt:
 *                   type: string
 */
app.post('/api/users', async (req: Request, res: Response) => {
  try {
    const user = await userService.create(req.body);
    res.status(201).json(user);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create user' });
  }
});

/**
 * @swagger
 * /api/users/{id}:
 *   put:
 *     summary: Update a user
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The user ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               email:
 *                 type: string
 *               role:
 *                 type: string
 *               companyId:
 *                 type: string
 *     responses:
 *       200:
 *         description: Updated user
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 email:
 *                   type: string
 *                 role:
 *                   type: string
 *                 companyId:
 *                   type: string
 *                 createdAt:
 *                   type: string
 */
app.put('/api/users/:id', async (req: Request, res: Response) => {
  try {
    const user = await userService.update(req.params.id, req.body);
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update user' });
  }
});

/**
 * @swagger
 * /api/users/{id}:
 *   delete:
 *     summary: Delete a user
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The user ID
 *     responses:
 *       204:
 *         description: User deleted successfully
 */
app.delete('/api/users/:id', async (req: Request, res: Response) => {
  try {
    await userService.delete(req.params.id);
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

// API routes for roles
/** 
 * @swagger
 * /api/roles:
 *   get:
 *     summary: Get all roles
 *     tags: [Roles]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of roles
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   name:
 *                     type: string
 *                   description:
 *                     type: string
 *                   createdAt:
 *                     type: string
 */
app.get('/api/roles', async (req: Request, res: Response) => {
  try {
    const roles = await roleService.getAll();
    res.json(roles);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch roles' });
  }
});

/** 
 * @swagger
 * /api/roles/{id}:
 *   get:
 *     summary: Get a role by ID
 *     tags: [Roles]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The role ID
 *     responses:
 *       200:
 *         description: A single role
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 description:
 *                   type: string
 *                 createdAt:
 *                   type: string
 *       404:
 *         description: Role not found
 */
app.get('/api/roles/:id', async (req: Request, res: Response) => {
  try {
    const role = await roleService.getById(req.params.id);
    if (!role) {
      return res.status(404).json({ error: 'Role not found' });
    }
    res.json(role);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch role' });
  }
});

/** 
 * @swagger
 * /api/roles:
 *   post:
 *     summary: Create a new role
 *     tags: [Roles]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: user
 *               description:
 *                 type: string
 *                 example: Regular user with limited access
 *     responses:
 *       201:
 *         description: Created role
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 description:
 *                   type: string
 *                 createdAt:
 *                   type: string
 */
app.post('/api/roles', async (req: Request, res: Response) => {
  try {
    const role = await roleService.create(req.body);
    res.status(201).json(role);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create role' });
  }
});

/** 
 * @swagger
 * /api/roles/{id}:
 *   put:
 *     summary: Update a role
 *     tags: [Roles]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The role ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: user
 *               description:
 *                 type: string
 *                 example: Regular user with limited access
 *     responses:
 *       200:
 *         description: Updated role
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 description:
 *                   type: string
 *                 createdAt:
 *                   type: string
 */
app.put('/api/roles/:id', async (req: Request, res: Response) => {
  try {
    const role = await roleService.update(req.params.id, req.body);
    res.json(role);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update role' });
  }
});

/** 
 * @swagger
 * /api/roles/{id}:
 *   delete:
 *     summary: Delete a role
 *     tags: [Roles]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The role ID
 *     responses:
 *       204:
 *         description: Role deleted successfully
 */
app.delete('/api/roles/:id', async (req: Request, res: Response) => {
  try {
    await roleService.delete(req.params.id);
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete role' });
  }
});

// API routes for menus
/** 
 * @swagger
 * /api/menus:
 *   get:
 *     summary: Get all menus
 *     tags: [Menus]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of menus
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   name:
 *                     type: string
 *                   path:
 *                     type: string
 *                   parentId:
 *                     type: string
 *                   order:
 *                     type: number
 *                   createdAt:
 *                     type: string
 */
app.get('/api/menus', async (req: Request, res: Response) => {
  try {
    const menus = await menuService.getAll();
    res.json(menus);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch menus' });
  }
});

/** 
 * @swagger
 * /api/menus/{id}:
 *   get:
 *     summary: Get a menu by ID
 *     tags: [Menus]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The menu ID
 *     responses:
 *       200:
 *         description: A single menu
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 path:
 *                   type: string
 *                 parentId:
 *                     type: string
 *                 order:
 *                   type: number
 *                 createdAt:
 *                   type: string
 *       404:
 *         description: Menu not found
 */
app.get('/api/menus/:id', async (req: Request, res: Response) => {
  try {
    const menu = await menuService.getById(req.params.id);
    if (!menu) {
      return res.status(404).json({ error: 'Menu not found' });
    }
    res.json(menu);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch menu' });
  }
});

/** 
 * @swagger
 * /api/menus:
 *   post:
 *     summary: Create a new menu
 *     tags: [Menus]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: Dashboard
 *               path:
 *                 type: string
 *                 example: /dashboard
 *               parentId:
 *                 type: string
 *                 example: null
 *               order:
 *                 type: number
 *                 example: 1
 *     responses:
 *       201:
 *         description: Created menu
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 path:
 *                   type: string
 *                 parentId:
 *                   type: string
 *                 order:
 *                   type: number
 *                 createdAt:
 *                   type: string
 */
app.post('/api/menus', async (req: Request, res: Response) => {
  try {
    const menu = await menuService.create(req.body);
    res.status(201).json(menu);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create menu' });
  }
});

/** 
 * @swagger
 * /api/menus/{id}:
 *   put:
 *     summary: Update a menu
 *     tags: [Menus]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The menu ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: Dashboard
 *               path:
 *                 type: string
 *                 example: /dashboard
 *               parentId:
 *                 type: string
 *                 example: null
 *               order:
 *                 type: number
 *                 example: 1
 *     responses:
 *       200:
 *         description: Updated menu
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 path:
 *                   type: string
 *                 parentId:
 *                   type: string
 *                 order:
 *                   type: number
 *                 createdAt:
 *                   type: string
 */
app.put('/api/menus/:id', async (req: Request, res: Response) => {
  try {
    const menu = await menuService.update(req.params.id, req.body);
    res.json(menu);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update menu' });
  }
});

/** 
 * @swagger
 * /api/menus/{id}:
 *   delete:
 *     summary: Delete a menu
 *     tags: [Menus]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The menu ID
 *     responses:
 *       204:
 *         description: Menu deleted successfully
 */
app.delete('/api/menus/:id', async (req: Request, res: Response) => {
  try {
    await menuService.delete(req.params.id);
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete menu' });
  }
});

// API routes for role permissions (user rights)
/** 
 * @swagger
 * /api/role-permissions:
 *   get:
 *     summary: Get all role permissions
 *     tags: [Role Permissions]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of role permissions
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   roleId:
 *                     type: string
 *                   menuId:
 *                     type: string
 *                   canView:
 *                     type: boolean
 *                   canCreate:
 *                     type: boolean
 *                   canEdit:
 *                     type: boolean
 *                   canDelete:
 *                     type: boolean
 *                   createdAt:
 *                     type: string
 *                   updatedAt:
 *                     type: string
 */
app.get('/api/role-permissions', async (req: Request, res: Response) => {
  try {
    const permissions = await rolePermissionService.getAll();
    res.json(permissions);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch role permissions' });
  }
});

/** 
 * @swagger
 * /api/role-permissions/{id}:
 *   get:
 *     summary: Get a role permission by ID
 *     tags: [Role Permissions]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The role permission ID
 *     responses:
 *       200:
 *         description: A single role permission
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 roleId:
 *                   type: string
 *                 menuId:
 *                   type: string
 *                 canView:
 *                   type: boolean
 *                 canCreate:
 *                   type: boolean
 *                 canEdit:
 *                   type: boolean
 *                 canDelete:
 *                   type: boolean
 *                 createdAt:
 *                   type: string
 *                 updatedAt:
 *                     type: string
 *       404:
 *         description: Role permission not found
 */
app.get('/api/role-permissions/:id', async (req: Request, res: Response) => {
  try {
    const permission = await rolePermissionService.getById(req.params.id);
    if (!permission) {
      return res.status(404).json({ error: 'Role permission not found' });
    }
    res.json(permission);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch role permission' });
  }
});

/** 
 * @swagger
 * /api/role-permissions:
 *   post:
 *     summary: Create a new role permission
 *     tags: [Role Permissions]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               roleId:
 *                 type: string
 *                 example: role_admin_id
 *               menuId:
 *                 type: string
 *                 example: menu_dashboard_id
 *               canView:
 *                 type: boolean
 *                 example: true
 *               canCreate:
 *                 type: boolean
 *                 example: true
 *               canEdit:
 *                 type: boolean
 *                 example: true
 *               canDelete:
 *                 type: boolean
 *                 example: false
 *     responses:
 *       201:
 *         description: Created role permission
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 roleId:
 *                   type: string
 *                 menuId:
 *                   type: string
 *                 canView:
 *                   type: boolean
 *                 canCreate:
 *                   type: boolean
 *                 canEdit:
 *                   type: boolean
 *                 canDelete:
 *                   type: boolean
 *                 createdAt:
 *                   type: string
 *                 updatedAt:
 *                   type: string
 */
app.post('/api/role-permissions', async (req: Request, res: Response) => {
  try {
    const permission = await rolePermissionService.create(req.body);
    res.status(201).json(permission);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create role permission' });
  }
});

/** 
 * @swagger
 * /api/role-permissions/{id}:
 *   put:
 *     summary: Update a role permission
 *     tags: [Role Permissions]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The role permission ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               canView:
 *                 type: boolean
 *                 example: true
 *               canCreate:
 *                 type: boolean
 *                 example: true
 *               canEdit:
 *                 type: boolean
 *                 example: true
 *               canDelete:
 *                 type: boolean
 *                 example: false
 *     responses:
 *       200:
 *         description: Updated role permission
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 roleId:
 *                   type: string
 *                 menuId:
 *                   type: string
 *                 canView:
 *                   type: boolean
 *                 canCreate:
 *                   type: boolean
 *                 canEdit:
 *                   type: boolean
 *                 canDelete:
 *                   type: boolean
 *                 createdAt:
 *                   type: string
 *                 updatedAt:
 *                   type: string
 */
app.put('/api/role-permissions/:id', async (req: Request, res: Response) => {
  try {
    const permission = await rolePermissionService.update(req.params.id, req.body);
    res.json(permission);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update role permission' });
  }
});

/** 
 * @swagger
 * /api/role-permissions/{id}:
 *   delete:
 *     summary: Delete a role permission
 *     tags: [Role Permissions]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The role permission ID
 *     responses:
 *       204:
 *         description: Role permission deleted successfully
 */
app.delete('/api/role-permissions/:id', async (req: Request, res: Response) => {
  try {
    await rolePermissionService.delete(req.params.id);
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete role permission' });
  }
});

/** 
 * @swagger
 * /api/role-permissions/bulk:
 *   post:
 *     summary: Set multiple role permissions at once
 *     tags: [Role Permissions]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               roleId:
 *                 type: string
 *                 example: role_admin_id
 *               permissions:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     menuId:
 *                       type: string
 *                       example: menu_dashboard_id
 *                     canView:
 *                       type: boolean
 *                       example: true
 *                     canCreate:
 *                       type: boolean
 *                       example: true
 *                     canEdit:
 *                       type: boolean
 *                       example: true
 *                     canDelete:
 *                       type: boolean
 *                       example: false
 *     responses:
 *       200:
 *         description: Bulk permissions updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                 updatedPermissions:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       id:
 *                         type: string
 *                       roleId:
 *                         type: string
 *                       menuId:
 *                         type: string
 *                       canView:
 *                         type: boolean
 *                       canCreate:
 *                         type: boolean
 *                       canEdit:
 *                         type: boolean
 *                       canDelete:
 *                         type: boolean
 */
app.post('/api/role-permissions/bulk', async (req: Request, res: Response) => {
  try {
    const { roleId, permissions } = req.body;
    
    if (!roleId || !permissions || !Array.isArray(permissions)) {
      return res.status(400).json({ error: 'roleId and permissions array are required' });
    }
    
    const results = [];
    for (const perm of permissions) {
      const { menuId, canView, canCreate, canEdit, canDelete } = perm;
      const result = await rolePermissionService.setPermissions(roleId, menuId, {
        canView,
        canCreate,
        canEdit,
        canDelete
      });
      results.push(result);
    }
    
    res.json({ 
      message: `Updated ${results.length} permissions for role ${roleId}`,
      updatedPermissions: results
    });
  } catch (error) {
    console.error('Bulk role permissions error:', error);
    res.status(500).json({ error: 'Failed to update role permissions in bulk' });
  }
});

/** 
 * @swagger
 * /api/role-permissions/role/{roleId}:
 *   get:
 *     summary: Get all permissions for a specific role
 *     tags: [Role Permissions]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: roleId
 *         required: true
 *         schema:
 *           type: string
 *         description: The role ID
 *     responses:
 *       200:
 *         description: A list of permissions for the role
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   roleId:
 *                     type: string
 *                   menuId:
 *                     type: string
 *                   canView:
 *                     type: boolean
 *                   canCreate:
 *                     type: boolean
 *                   canEdit:
 *                     type: boolean
 *                   canDelete:
 *                     type: boolean
 *                   createdAt:
 *                     type: string
 *                   updatedAt:
 *                     type: string
 */
app.get('/api/role-permissions/role/:roleId', async (req: Request, res: Response) => {
  try {
    const permissions = await rolePermissionService.getByRoleId(req.params.roleId);
    res.json(permissions);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch role permissions' });
  }
});

/** 
 * @swagger
 * /api/user-rights/{userId}:
 *   get:
 *     summary: Get permissions for a specific user based on their role
 *     tags: [User Rights]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *         description: The user ID
 *     responses:
 *       200:
 *         description: User's permissions based on their role
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 user:
 *                   type: object
 *                   properties:
 *                     id:
 *                       type: string
 *                     name:
 *                       type: string
 *                     role:
 *                       type: object
 *                       properties:
 *                         id:
 *                           type: string
 *                         name:
 *                           type: string
 *                 permissions:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       id:
 *                         type: string
 *                       menuId:
 *                         type: string
 *                       menu:
 *                         type: object
 *                         properties:
 *                           id:
 *                             type: string
 *                           name:
 *                             type: string
 *                           path:
 *                             type: string
 *                       canView:
 *                         type: boolean
 *                       canCreate:
 *                         type: boolean
 *                       canEdit:
 *                         type: boolean
 *                       canDelete:
 *                         type: boolean
 */
app.get('/api/user-rights/:userId', async (req: Request, res: Response) => {
  try {
    // Get user and their role
    const user = await userService.getById(req.params.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    if (!user.roleId) {
      // For backward compatibility, if no role is set, return base permissions
      return res.json({ 
        user: { 
          id: user.id, 
          name: user.name, 
          role: null 
        }, 
        permissions: [] 
      });
    }
    
    // Get permissions for the user's role
    const permissions = await rolePermissionService.getByRoleId(user.roleId);
    
    res.json({ 
      user: { 
        id: user.id, 
        name: user.name, 
        role: user.role 
      }, 
      permissions 
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch user rights' });
  }
});

// API routes for licenses
/**
 * @swagger
 * /api/licenses:
 *   get:
 *     summary: Get all licenses
 *     tags: [Licenses]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of licenses
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   key:
 *                     type: string
 *                   productId:
 *                     type: string
 *                   planId:
 *                     type: string
 *                   userId:
 *                     type: string
 *                   status:
 *                     type: string
 *                   expiresAt:
 *                     type: string
 *                   createdAt:
 *                     type: string
 *                   invoiceId:
 *                     type: string
 */
app.get('/api/licenses', async (req: Request, res: Response) => {
  try {
    const licenses = await licenseService.getAll();
    res.json(licenses);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch licenses' });
  }
});

/**
 * @swagger
 * /api/licenses/{id}:
 *   get:
 *     summary: Get a license by ID
 *     tags: [Licenses]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The license ID
 *     responses:
 *       200:
 *         description: A single license
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 key:
 *                   type: string
 *                 productId:
 *                   type: string
 *                 planId:
 *                   type: string
 *                 userId:
 *                   type: string
 *                 status:
 *                   type: string
 *                 expiresAt:
 *                   type: string
 *                 createdAt:
 *                   type: string
 *                 invoiceId:
 *                   type: string
 *       404:
 *         description: License not found
 */
app.get('/api/licenses/:id', async (req: Request, res: Response) => {
  try {
    const license = await licenseService.getById(req.params.id);
    if (!license) {
      return res.status(404).json({ error: 'License not found' });
    }
    res.json(license);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch license' });
  }
});

/**
 * @swagger
 * /api/licenses:
 *   post:
 *     summary: Create a new license
 *     tags: [Licenses]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               key:
 *                 type: string
 *               productId:
 *                 type: string
 *               planId:
 *                 type: string
 *               userId:
 *                 type: string
 *               status:
 *                 type: string
 *               expiresAt:
 *                 type: string
 *               invoiceId:
 *                 type: string
 *     responses:
 *       201:
 *         description: Created license
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 key:
 *                   type: string
 *                 productId:
 *                   type: string
 *                 planId:
 *                   type: string
 *                 userId:
 *                   type: string
 *                 status:
 *                   type: string
 *                 expiresAt:
 *                   type: string
 *                 createdAt:
 *                   type: string
 *                 invoiceId:
 *                   type: string
 */
app.post('/api/licenses', async (req: Request, res: Response) => {
  try {
    const license = await licenseService.create(req.body);
    res.status(201).json(license);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create license' });
  }
});

/**
 * @swagger
 * /api/licenses/{id}:
 *   put:
 *     summary: Update a license
 *     tags: [Licenses]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The license ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               key:
 *                 type: string
 *               productId:
 *                 type: string
 *               planId:
 *                 type: string
 *               userId:
 *                 type: string
 *               status:
 *                 type: string
 *               expiresAt:
 *                 type: string
 *               invoiceId:
 *                 type: string
 *     responses:
 *       200:
 *         description: Updated license
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 key:
 *                   type: string
 *                 productId:
 *                   type: string
 *                 planId:
 *                   type: string
 *                 userId:
 *                   type: string
 *                 status:
 *                   type: string
 *                 expiresAt:
 *                   type: string
 *                 createdAt:
 *                   type: string
 *                 invoiceId:
 *                   type: string
 */
app.put('/api/licenses/:id', async (req: Request, res: Response) => {
  try {
    const license = await licenseService.update(req.params.id, req.body);
    res.json(license);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update license' });
  }
});

/**
 * @swagger
 * /api/licenses/{id}:
 *   delete:
 *     summary: Delete a license
 *     tags: [Licenses]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The license ID
 *     responses:
 *       204:
 *         description: License deleted successfully
 */
app.delete('/api/licenses/:id', async (req: Request, res: Response) => {
  try {
    await licenseService.delete(req.params.id);
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete license' });
  }
});

/** 
 * @swagger
 * /api/licenses/activate:
 *   post:
 *     summary: Activate a license on a device
 *     tags: [Licenses]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               licenseKey:
 *                 type: string
 *                 description: The license key to activate
 *               productName:
 *                 type: string
 *                 description: The product name to activate the license for
 *               device:
 *                 type: object
 *                 properties:
 *                   computerId:
 *                     type: string
 *                     description: Unique computer ID
 *                   name:
 *                     type: string
 *                     description: Device name
 *                   os:
 *                     type: string
 *                     description: Operating system
 *                   processor:
 *                     type: string
 *                     description: Processor information
 *                   ram:
 *                     type: string
 *                     description: RAM information
 *     responses:
 *       200:
 *         description: License activated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 message:
 *                   type: string
 *                 license:
 *                   type: object
 *                   properties:
 *                     key:
 *                       type: string
 *                     isActive:
 *                       type: boolean
 *                     expiresAt:
 *                       type: string
 *                 device:
 *                   type: object
 *                   properties:
 *                     id:
 *                       type: string
 *                     name:
 *                       type: string
 *                     activatedAt:
 *                       type: string
 *                     lastSeenAt:
 *                       type: string
 *       400:
 *         description: Bad request - invalid license key, device limit reached, etc.
 *       404:
 *         description: License not found
 */
app.post('/api/licenses/activate', async (req: Request, res: Response) => {
  try {
    const { licenseKey, productName, device } = req.body;

    if (!licenseKey || !device || !device.computerId) {
      return res.status(400).json({ 
        success: false,
        error: 'INVALID_INPUT',
        message: 'License key and device computerId are required' 
      });
    }

    // Find the license by key
    const licenses = await licenseService.getAll();
    const license = licenses.find(l => l.key === licenseKey);

    if (!license) {
      return res.status(404).json({ 
        success: false,
        error: 'INVALID_LICENSE_KEY',
        message: 'The provided license key is not valid or does not exist.' 
      });
    }

    // Check if the license is already expired
    if (license.expiresAt && new Date(license.expiresAt) < new Date()) {
      await licenseService.update(license.id, { status: 'Expired' });
      return res.status(400).json({ 
        success: false,
        error: 'EXPIRED_LICENSE',
        message: 'The license has expired.' 
      });
    }

    // Get the plan to check device limit
    const plan = license.planId ? await planService.getById(license.planId) : null;
    const deviceLimit = plan ? plan.deviceLimit : 1; // Default to 1 if no plan

    // Check existing devices for this license
    const devices = await deviceService.getAll();
    const existingDevices = devices.filter(d => d.licenseId === license.id);
    
    if (existingDevices.length >= deviceLimit) {
      return res.status(400).json({ 
        success: false,
        error: 'DEVICE_LIMIT_REACHED',
        message: 'The maximum number of devices for this license has been reached.' 
      });
    }

    // Check if this computerId is already registered for this license
    const existingDevice = existingDevices.find(d => d.computerId === device.computerId);
    if (existingDevice) {
      // Update the existing device's last seen time
      const updatedDevice = await deviceService.update(existingDevice.id, {
        lastSeenAt: new Date().toISOString()
      });
      
      return res.status(200).json({
        success: true,
        message: 'Device heartbeat received successfully. License is active.',
        license: {
          key: license.key,
          isActive: license.status === 'Active',
          expiresAt: license.expiresAt
        },
        device: updatedDevice
      });
    }

    // Create new device
    const newDevice = await deviceService.create({
      licenseId: license.id,
      computerId: device.computerId,
      name: device.name || 'Unknown Device',
      os: device.os,
      processor: device.processor,
      ram: device.ram,
      isActive: true,
      activatedAt: new Date().toISOString(),
      lastSeenAt: new Date().toISOString()
    });

    // Update license status to active if it wasn't already
    if (license.status !== 'Active') {
      await licenseService.update(license.id, { status: 'Active' });
    }

    res.status(200).json({
      success: true,
      message: 'License activated successfully.',
      license: {
        key: license.key,
        isActive: true,
        expiresAt: license.expiresAt
      },
      device: newDevice
    });
  } catch (error) {
    console.error('License activation error:', error);
    res.status(500).json({ 
      success: false,
      error: 'ACTIVATION_ERROR',
      message: 'An error occurred during license activation.' 
    });
  }
});

/** 
 * @swagger
 * /api/devices/heartbeat:
 *   post:
 *     summary: Device heartbeat to check license status and update last seen time
 *     tags: [Devices]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               licenseKey:
 *                 type: string
 *                 description: The license key
 *               computerId:
 *                 type: string
 *                 description: Computer ID of the device
 *     responses:
 *       200:
 *         description: Heartbeat received successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 licenseStatus:
 *                   type: string
 *                   description: active, inactive, or expired
 *                 message:
 *                   type: string
 *       404:
 *         description: Device not found
 */
app.post('/api/devices/heartbeat', async (req: Request, res: Response) => {
  try {
    const { licenseKey, computerId } = req.body;

    if (!licenseKey || !computerId) {
      return res.status(400).json({ 
        success: false,
        error: 'MISSING_PARAMETERS',
        message: 'License key and computer ID are required' 
      });
    }

    // Find the license by key
    const licenses = await licenseService.getAll();
    const license = licenses.find(l => l.key === licenseKey);

    if (!license) {
      return res.status(404).json({ 
        success: false,
        error: 'LICENSE_NOT_FOUND',
        message: 'The provided license key does not exist.' 
      });
    }

    // Find the device by license and computer ID
    const devices = await deviceService.getAll();
    const device = devices.find(d => d.licenseId === license.id && d.computerId === computerId);

    if (!device) {
      return res.status(404).json({ 
        success: false,
        error: 'DEVICE_NOT_FOUND',
        message: 'No active device with the specified computerId was found for this license.' 
      });
    }

    // Update the last seen time
    await deviceService.update(device.id, {
      lastSeenAt: new Date().toISOString()
    });

    // Check license expiration
    let licenseStatus = license.status;
    if (license.expiresAt && new Date(license.expiresAt) < new Date()) {
      licenseStatus = 'expired';
      // Update the license status in the database
      await licenseService.update(license.id, { status: 'Expired' });
    }

    res.status(200).json({
      success: true,
      licenseStatus: licenseStatus.toLowerCase(),
      message: 'Heartbeat received. License is ' + licenseStatus.toLowerCase() + '.'
    });
  } catch (error) {
    console.error('Heartbeat error:', error);
    res.status(500).json({ 
      success: false,
      error: 'HEARTBEAT_ERROR',
      message: 'An error occurred during heartbeat.' 
    });
  }
});

// API routes for devices
/**
 * @swagger
 * /api/devices:
 *   get:
 *     summary: Get all devices
 *     tags: [Devices]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of devices
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   licenseId:
 *                     type: string
 *                   computerId:
 *                     type: string
 *                   name:
 *                     type: string
 *                   processor:
 *                     type: string
 *                   os:
 *                     type: string
 *                   ram:
 *                     type: string
 *                   isActive:
 *                     type: boolean
 *                   activatedAt:
 *                     type: string
 *                   lastSeenAt:
 *                     type: string
 */
app.get('/api/devices', async (req: Request, res: Response) => {
  try {
    const devices = await deviceService.getAll();
    res.json(devices);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch devices' });
  }
});

/**
 * @swagger
 * /api/devices/{id}:
 *   get:
 *     summary: Get a device by ID
 *     tags: [Devices]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The device ID
 *     responses:
 *       200:
 *         description: A single device
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 licenseId:
 *                   type: string
 *                 computerId:
 *                   type: string
 *                 name:
 *                   type: string
 *                 processor:
 *                   type: string
 *                 os:
 *                   type: string
 *                 ram:
 *                   type: string
 *                 isActive:
 *                   type: boolean
 *                 activatedAt:
 *                   type: string
 *                 lastSeenAt:
 *                   type: string
 *       404:
 *         description: Device not found
 */
app.get('/api/devices/:id', async (req: Request, res: Response) => {
  try {
    const device = await deviceService.getById(req.params.id);
    if (!device) {
      return res.status(404).json({ error: 'Device not found' });
    }
    res.json(device);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch device' });
  }
});

/**
 * @swagger
 * /api/devices:
 *   post:
 *     summary: Create a new device
 *     tags: [Devices]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               licenseId:
 *                 type: string
 *               computerId:
 *                 type: string
 *               name:
 *                 type: string
 *               processor:
 *                 type: string
 *               os:
 *                 type: string
 *               ram:
 *                 type: string
 *               isActive:
 *                 type: boolean
 *     responses:
 *       201:
 *         description: Created device
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 licenseId:
 *                   type: string
 *                 computerId:
 *                   type: string
 *                 name:
 *                   type: string
 *                 processor:
 *                   type: string
 *                 os:
 *                   type: string
 *                 ram:
 *                   type: string
 *                 isActive:
 *                   type: boolean
 *                 activatedAt:
 *                   type: string
 *                 lastSeenAt:
 *                   type: string
 */
app.post('/api/devices', async (req: Request, res: Response) => {
  try {
    const device = await deviceService.create(req.body);
    res.status(201).json(device);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create device' });
  }
});

/**
 * @swagger
 * /api/devices/{id}:
 *   put:
 *     summary: Update a device
 *     tags: [Devices]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The device ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               processor:
 *                 type: string
 *               os:
 *                 type: string
 *               ram:
 *                 type: string
 *               isActive:
 *                 type: boolean
 *     responses:
 *       200:
 *         description: Updated device
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 licenseId:
 *                   type: string
 *                 computerId:
 *                   type: string
 *                 name:
 *                   type: string
 *                 processor:
 *                   type: string
 *                 os:
 *                   type: string
 *                 ram:
 *                   type: string
 *                 isActive:
 *                   type: boolean
 *                 activatedAt:
 *                   type: string
 *                 lastSeenAt:
 *                   type: string
 */
app.put('/api/devices/:id', async (req: Request, res: Response) => {
  try {
    const device = await deviceService.update(req.params.id, req.body);
    res.json(device);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update device' });
  }
});

/**
 * @swagger
 * /api/devices/{id}:
 *   delete:
 *     summary: Delete a device
 *     tags: [Devices]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The device ID
 *     responses:
 *       204:
 *         description: Device deleted successfully
 */
app.delete('/api/devices/:id', async (req: Request, res: Response) => {
  try {
    await deviceService.delete(req.params.id);
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete device' });
  }
});

// API routes for invoices
/**
 * @swagger
 * /api/invoices:
 *   get:
 *     summary: Get all invoices
 *     tags: [Invoices]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of invoices
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   invoiceNumber:
 *                     type: string
 *                   companyId:
 *                     type: string
 *                   issueDate:
 *                     type: string
 *                   dueDate:
 *                     type: string
 *                   total:
 *                     type: number
 *                   status:
 *                     type: string
 *                   paymentMethod:
 *                     type: string
 *                   bankId:
 *                     type: string
 *                   createdAt:
 *                     type: string
 */
app.get('/api/invoices', async (req: Request, res: Response) => {
  try {
    const invoices = await invoiceService.getAll();
    res.json(invoices);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch invoices' });
  }
});

/**
 * @swagger
 * /api/invoices/{id}:
 *   get:
 *     summary: Get an invoice by ID
 *     tags: [Invoices]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The invoice ID
 *     responses:
 *       200:
 *         description: A single invoice
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 invoiceNumber:
 *                   type: string
 *                 companyId:
 *                   type: string
 *                 issueDate:
 *                   type: string
 *                 dueDate:
 *                   type: string
 *                 total:
 *                   type: number
 *                 status:
 *                   type: string
 *                 paymentMethod:
 *                   type: string
 *                 bankId:
 *                   type: string
 *                 createdAt:
 *                   type: string
 *       404:
 *         description: Invoice not found
 */
app.get('/api/invoices/:id', async (req: Request, res: Response) => {
  try {
    const invoice = await invoiceService.getById(req.params.id);
    if (!invoice) {
      return res.status(404).json({ error: 'Invoice not found' });
    }
    res.json(invoice);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch invoice' });
  }
});

/**
 * @swagger
 * /api/invoices:
 *   post:
 *     summary: Create a new invoice
 *     tags: [Invoices]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               invoiceNumber:
 *                 type: string
 *               companyId:
 *                 type: string
 *               issueDate:
 *                 type: string
 *               dueDate:
 *                 type: string
 *               total:
 *                 type: number
 *               status:
 *                 type: string
 *               paymentMethod:
 *                 type: string
 *               bankId:
 *                 type: string
 *               lineItems:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     planId:
 *                       type: string
 *                     description:
 *                       type: string
 *                     quantity:
 *                       type: number
 *                     unitPrice:
 *                       type: number
 *                     total:
 *                       type: number
 *     responses:
 *       201:
 *         description: Created invoice
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 invoiceNumber:
 *                   type: string
 *                 companyId:
 *                   type: string
 *                 issueDate:
 *                   type: string
 *                 dueDate:
 *                   type: string
 *                 total:
 *                   type: number
 *                 status:
 *                   type: string
 *                 paymentMethod:
 *                   type: string
 *                 bankId:
 *                   type: string
 *                 createdAt:
 *                   type: string
 */
app.post('/api/invoices', async (req: Request, res: Response) => {
  console.log('POST /api/invoices - Request body:', req.body);
  try {
    const invoice = await invoiceService.create(req.body);
    console.log('POST /api/invoices - Created invoice:', invoice);
    res.status(201).json(invoice);
  } catch (error) {
    console.error('POST /api/invoices - Error:', error);
    res.status(500).json({ error: 'Failed to create invoice', details: (error as Error).message });
  }
});

/**
 * @swagger
 * /api/invoices/{id}:
 *   put:
 *     summary: Update an invoice
 *     tags: [Invoices]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The invoice ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               invoiceNumber:
 *                 type: string
 *               issueDate:
 *                 type: string
 *               dueDate:
 *                 type: string
 *               total:
 *                 type: number
 *               status:
 *                 type: string
 *               paymentMethod:
 *                 type: string
 *               bankId:
 *                 type: string
 *     responses:
 *       200:
 *         description: Updated invoice
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 invoiceNumber:
 *                   type: string
 *                 companyId:
 *                   type: string
 *                 issueDate:
 *                   type: string
 *                 dueDate:
 *                   type: string
 *                 total:
 *                   type: number
 *                 status:
 *                   type: string
 *                 paymentMethod:
 *                   type: string
 *                 bankId:
 *                   type: string
 *                 createdAt:
 *                   type: string
 */
app.put('/api/invoices/:id', async (req: Request, res: Response) => {
  try {
    const invoice = await invoiceService.update(req.params.id, req.body);
    res.json(invoice);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update invoice' });
  }
});

/**
 * @swagger
 * /api/invoices/{id}:
 *   delete:
 *     summary: Delete an invoice
 *     tags: [Invoices]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The invoice ID
 *     responses:
 *       204:
 *         description: Invoice deleted successfully
 */
app.delete('/api/invoices/:id', async (req: Request, res: Response) => {
  try {
    await invoiceService.delete(req.params.id);
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete invoice' });
  }
});

// API routes for activity logs
/**
 * @swagger
 * /api/activity-logs:
 *   get:
 *     summary: Get all activity logs
 *     tags: [Activity Logs]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of activity logs
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   userId:
 *                     type: string
 *                   action:
 *                     type: string
 *                   entityType:
 *                     type: string
 *                   entityName:
 *                     type: string
 *                   createdAt:
 *                     type: string
 *                   details:
 *                     type: object
 */
app.get('/api/activity-logs', async (req: Request, res: Response) => {
  try {
    const activityLogs = await activityLogService.getAll();
    res.json(activityLogs);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch activity logs' });
  }
});

/**
 * @swagger
 * /api/activity-logs/{id}:
 *   get:
 *     summary: Get an activity log by ID
 *     tags: [Activity Logs]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The activity log ID
 *     responses:
 *       200:
 *         description: A single activity log
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 userId:
 *                   type: string
 *                 action:
 *                   type: string
 *                 entityType:
 *                   type: string
 *                 entityName:
 *                   type: string
 *                 createdAt:
 *                   type: string
 *                 details:
 *                   type: object
 *       404:
 *         description: Activity log not found
 */
app.get('/api/activity-logs/:id', async (req: Request, res: Response) => {
  try {
    const activityLog = await activityLogService.getById(req.params.id);
    if (!activityLog) {
      return res.status(404).json({ error: 'Activity log not found' });
    }
    res.json(activityLog);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch activity log' });
  }
});

/**
 * @swagger
 * /api/activity-logs:
 *   post:
 *     summary: Create a new activity log
 *     tags: [Activity Logs]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               userId:
 *                 type: string
 *               action:
 *                 type: string
 *               entityType:
 *                 type: string
 *               entityName:
 *                 type: string
 *               details:
 *                 type: object
 *     responses:
 *       201:
 *         description: Created activity log
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 userId:
 *                   type: string
 *                 action:
 *                   type: string
 *                 entityType:
 *                   type: string
 *                 entityName:
 *                   type: string
 *                 createdAt:
 *                   type: string
 *                 details:
 *                   type: object
 */
app.post('/api/activity-logs', async (req: Request, res: Response) => {
  try {
    const activityLog = await activityLogService.create(req.body);
    res.status(201).json(activityLog);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create activity log' });
  }
});
/** 
 * @swagger
 * /api/activity-logs/clear:
 *   delete:
 *     summary: Delete all activity logs
 *     tags: [Activity Logs]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       204:
 *         description: All activity logs deleted successfully
 */
app.delete('/api/activity-logs/clear', async (req: Request, res: Response) => {
  console.log('DELETE /api/activity-logs/clear - Request received');
  try {
    console.log('DELETE /api/activity-logs/clear - Calling activityLogService.deleteAll()');
    const result = await activityLogService.deleteAll();
    console.log('DELETE /api/activity-logs/clear - deleteAll completed, result:', result);
    res.status(204).send();
  } catch (error) {
    console.error('DELETE /api/activity-logs/clear - Error:', error);
    res.status(500).json({ error: 'Failed to delete all activity logs', details: (error as Error).message });
  }
});
/**
 * @swagger
 * /api/activity-logs/{id}:
 *   delete:
 *     summary: Delete an activity log
 *     tags: [Activity Logs]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The activity log ID
 *     responses:
 *       204:
 *         description: Activity log deleted successfully
 */
app.delete('/api/activity-logs/:id', async (req: Request, res: Response) => {
  try {
    await activityLogService.delete(req.params.id);
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete activity log' });
  }
});



// API routes for banks
/**
 * @swagger
 * /api/banks:
 *   get:
 *     summary: Get all banks
 *     tags: [Banks]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of banks
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                   name:
 *                     type: string
 *                   accountNumber:
 *                     type: string
 *                   ownerName:
 *                     type: string
 */
app.get('/api/banks', async (req: Request, res: Response) => {
  try {
    const banks = await bankService.getAll();
    res.json(banks);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch banks' });
  }
});

/**
 * @swagger
 * /api/banks/{id}:
 *   get:
 *     summary: Get a bank by ID
 *     tags: [Banks]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The bank ID
 *     responses:
 *       200:
 *         description: A single bank
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 accountNumber:
 *                   type: string
 *                 ownerName:
 *                   type: string
 *       404:
 *         description: Bank not found
 */
app.get('/api/banks/:id', async (req: Request, res: Response) => {
  try {
    const bank = await bankService.getById(req.params.id);
    if (!bank) {
      return res.status(404).json({ error: 'Bank not found' });
    }
    res.json(bank);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch bank' });
  }
});

/**
 * @swagger
 * /api/banks:
 *   post:
 *     summary: Create a new bank
 *     tags: [Banks]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               accountNumber:
 *                 type: string
 *               ownerName:
 *                 type: string
 *     responses:
 *       201:
 *         description: Created bank
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 accountNumber:
 *                   type: string
 *                 ownerName:
 *                   type: string
 */
app.post('/api/banks', async (req: Request, res: Response) => {
  try {
    const bank = await bankService.create(req.body);
    res.status(201).json(bank);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create bank' });
  }
});

/**
 * @swagger
 * /api/banks/{id}:
 *   put:
 *     summary: Update a bank
 *     tags: [Banks]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The bank ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               accountNumber:
 *                 type: string
 *               ownerName:
 *                 type: string
 *     responses:
 *       200:
 *         description: Updated bank
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 name:
 *                   type: string
 *                 accountNumber:
 *                   type: string
 *                 ownerName:
 *                   type: string
 */
app.put('/api/banks/:id', async (req: Request, res: Response) => {
  try {
    const bank = await bankService.update(req.params.id, req.body);
    res.json(bank);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update bank' });
  }
});

/**
 * @swagger
 * /api/banks/{id}:
 *   delete:
 *     summary: Delete a bank
 *     tags: [Banks]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The bank ID
 *     responses:
 *       204:
 *         description: Bank deleted successfully
 */
app.delete('/api/banks/:id', async (req: Request, res: Response) => {
  try {
    await bankService.delete(req.params.id);
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete bank' });
  }
});

// Authentication endpoints






// Error handling middleware
app.use((err: Error, req: Request, res: Response, next: Function) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
  console.log(`Swagger documentation available at http://localhost:${PORT}/api-docs`);
});