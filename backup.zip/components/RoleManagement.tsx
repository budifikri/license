import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from './ui/Card';
import Button from './ui/Button';
import { apiClient } from '@/lib/api/client';
import type { Role } from '../../types';

const RoleManagement: React.FC = () => {
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');

  useEffect(() => {
    loadRoles();
  }, []);

  const loadRoles = async () => {
    setLoading(true);
    try {
      const response = await apiClient.get<Role[]>('roles');
      if (response.error) throw new Error(response.error);
      setRoles(response.data || []);
    } catch (error) {
      console.error('Error loading roles:', error);
      setMessage('Error loading roles: ' + (error instanceof Error ? error.message : 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <p>Loading roles...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Role Management</h1>
          <p className="text-muted-foreground">Manage roles and their access permissions</p>
        </div>
        <div className="flex space-x-2">
          <Button 
            variant="outline"
            onClick={() => {
              // Navigate to menu permissions page
              window.location.hash = '#menu-permissions';
            }}
          >
            Role Permissions Matrix
          </Button>
          <Button 
            variant="outline"
            onClick={() => {
              // Navigate to menu item permissions table
              window.location.hash = '#menu-item-permissions';
            }}
          >
            Menu Item Permissions
          </Button>
          <Button>Add Role</Button>
        </div>
      </div>

      {message && (
        <div className={`p-4 rounded-md ${message.includes('Error') ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
          {message}
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Role List</CardTitle>
          <CardDescription>Manage available roles in the system</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2">ID</th>
                  <th className="text-left py-2">Name</th>
                  <th className="text-left py-2">Description</th>
                  <th className="text-center py-2">Actions</th>
                </tr>
              </thead>
              <tbody>
                {roles.length > 0 ? (
                  roles.map(role => (
                    <tr key={role.id} className="border-b">
                      <td className="py-2 font-mono text-sm">{role.id}</td>
                      <td className="py-2">{role.name}</td>
                      <td className="py-2">{role.description}</td>
                      <td className="py-2 text-center">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => {
                            // Navigate to role permission page
                            window.location.hash = `#role-permissions/${role.id}`;
                          }}
                        >
                          Manage Access
                        </Button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={4} className="text-center py-4 text-muted-foreground">
                      No roles found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Button onClick={loadRoles}>Refresh Data</Button>
    </div>
  );
};

export default RoleManagement;