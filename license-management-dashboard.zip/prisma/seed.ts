import { PrismaClient } from '@prisma/client';
import { v4 as uuidv4 } from 'uuid';
import { exit } from 'process';

const prisma = new PrismaClient();

async function main() {
    console.log(`Start seeding ...`);

    // Clean up existing data in the correct order
    await prisma.device.deleteMany();
    await prisma.invoiceLineItem.deleteMany();
    await prisma.licenseKey.deleteMany();
    await prisma.invoice.deleteMany();
    await prisma.activityLog.deleteMany();
    await prisma.plan.deleteMany();
    await prisma.product.deleteMany();
    await prisma.user.deleteMany();
    await prisma.company.deleteMany();
    await prisma.bank.deleteMany();
    
    console.log('Cleaned up old data.');

    const banks = await prisma.bank.createManyAndReturn({
        data: [
            { name: 'Bank Central Asia (BCA)', accountNumber: '1234567890', ownerName: 'Innovate Corp' },
            { name: 'Bank Mandiri', accountNumber: '0987654321', ownerName: 'Innovate Corp' },
            { name: 'Bank Rakyat Indonesia (BRI)', accountNumber: '1122334455', ownerName: 'Innovate Corp' },
        ],
    });
    console.log(`Created ${banks.length} banks.`);

    const companies = await prisma.company.createManyAndReturn({
        data: [ { name: 'Innovate Corp' }, { name: 'Future Solutions' }, { name: 'QuantumLeap Tech' } ],
    });
    console.log(`Created ${companies.length} companies.`);

    const users = await prisma.user.createManyAndReturn({
        data: [
            { name: 'Admin User', email: 'admin@gmail.com', role: 'Admin', companyId: companies[0].id },
            { name: 'Alice Johnson', email: 'alice@innovate.com', role: 'Admin', companyId: companies[0].id },
            { name: 'Bob Smith', email: 'bob@future.com', role: 'Manager', companyId: companies[1].id },
            { name: 'Charlie Brown', email: 'charlie@quantum.com', role: 'User', companyId: companies[2].id },
            { name: 'Diana Prince', email: 'diana@innovate.com', role: 'User', companyId: companies[0].id },
        ],
    });
    console.log(`Created ${users.length} users.`);

    const products = await prisma.product.createManyAndReturn({
        data: [
            { name: 'NexusDB', description: 'A high-performance, scalable NoSQL database for modern applications.' },
            { name: 'CodeGenius', description: 'An AI-powered code completion tool that boosts developer productivity.' },
            { name: 'PixelPerfect', description: 'A collaborative design platform for UI/UX teams.' },
        ],
    });
    console.log(`Created ${products.length} products.`);

    const plans = await prisma.plan.createManyAndReturn({
        data: [
            { productId: products[0].id, name: 'Basic', price: 735000, deviceLimit: 1, durationDays: 365 },
            { productId: products[0].id, name: 'Pro', price: 1485000, deviceLimit: 5, durationDays: 365 },
            { productId: products[0].id, name: 'Enterprise', price: 7485000, deviceLimit: 50, durationDays: 0 },
            { productId: products[1].id, name: 'Individual', price: 150000, deviceLimit: 1, durationDays: 30 },
            { productId: products[1].id, name: 'Team', price: 675000, deviceLimit: 5, durationDays: 365 },
            { productId: products[2].id, name: 'Free', price: 0, deviceLimit: 2, durationDays: 0 },
            { productId: products[2].id, name: 'Professional', price: 375000, deviceLimit: 10, durationDays: 365 },
        ],
    });
    console.log(`Created ${plans.length} plans.`);

    const invoice1 = await prisma.invoice.create({
        data: {
            invoiceNumber: 'INV-2024-001', companyId: companies[0].id, issueDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000), dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000), status: 'Unpaid', paymentMethod: 'Bank', bankId: banks[0].id, total: (plans[1].price * 2) + plans[4].price,
            lineItems: { create: [
                { planId: plans[1].id, description: `${products[0].name} - ${plans[1].name}`, quantity: 2, unitPrice: plans[1].price, total: plans[1].price * 2 },
                { planId: plans[4].id, description: `${products[1].name} - ${plans[4].name}`, quantity: 1, unitPrice: plans[4].price, total: plans[4].price * 1 },
            ]}
        },
        include: { lineItems: true }
    });
    
    const invoice2 = await prisma.invoice.create({
        data: {
            invoiceNumber: 'INV-2024-002', companyId: companies[1].id, issueDate: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000), dueDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000), status: 'Overdue', paymentMethod: 'Qris', total: plans[6].price * 5,
            lineItems: { create: [ { planId: plans[6].id, description: `${products[2].name} - ${plans[6].name}`, quantity: 5, unitPrice: plans[6].price, total: plans[6].price * 5 } ]}
        },
        include: { lineItems: true }
    });

    const invoice3 = await prisma.invoice.create({
        data: {
            invoiceNumber: 'INV-2024-003', companyId: companies[2].id, issueDate: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000), dueDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), status: 'Paid', paymentMethod: 'Cash', total: plans[1].price * 10,
            lineItems: { create: [ { planId: plans[1].id, description: `${products[0].name} - ${plans[1].name}`, quantity: 10, unitPrice: plans[1].price, total: plans[1].price * 10 } ]}
        },
        include: { lineItems: true }
    });
    console.log('Created 3 invoices.');

    const allInvoices = [invoice1, invoice2, invoice3];
    const licensesToCreate = [];

    // Create licenses for invoices
    for (const invoice of allInvoices) {
        const companyUsers = users.filter(u => u.companyId === invoice.companyId);
        if (companyUsers.length > 0) {
            for (const item of invoice.lineItems) {
                const plan = plans.find(p => p.id === item.planId);
                if (plan) {
                    for (let i = 0; i < item.quantity; i++) {
                        const expiresAt = plan.durationDays > 0 ? new Date(Date.now() + plan.durationDays * 24 * 60 * 60 * 1000) : null;
                        const isExpired = expiresAt ? expiresAt < new Date() : false;
                        licensesToCreate.push({
                            key: uuidv4().toUpperCase(), productId: plan.productId, planId: plan.id, userId: companyUsers[0].id,
                            status: isExpired ? 'Expired' : invoice.status === 'Paid' ? 'Active' : 'Inactive',
                            expiresAt: expiresAt,
                            invoiceId: invoice.id
                        });
                    }
                }
            }
        }
    }
    
    // Create some un-invoiced licenses
    for (let i = 0; i < 10; i++) {
        const plan = plans[i % plans.length];
        const user = users[i % users.length];
        const isActive = Math.random() > 0.2;
        const expiresAt = plan.durationDays > 0 ? new Date(Date.now() + plan.durationDays * 24 * 60 * 60 * 1000) : null;
        const isExpired = expiresAt ? expiresAt < new Date() : false;

        licensesToCreate.push({
            key: uuidv4().toUpperCase(), productId: plan.productId, planId: plan.id, userId: user.id,
            status: isExpired ? 'Expired' : isActive ? 'Active' : 'Inactive',
            expiresAt: expiresAt,
            invoiceId: null
        });
    }

    await prisma.licenseKey.createMany({ data: licensesToCreate });
    const licenses = await prisma.licenseKey.findMany();
    console.log(`Created ${licenses.length} licenses.`);

    // Seed Devices
    const devicesToCreate = [];
    for (const license of licenses) {
        const plan = plans.find(p => p.id === license.planId)!;
        if (plan.deviceLimit > 0 && Math.random() > 0.5) { // 50% chance to have devices
             const deviceCount = Math.floor(Math.random() * plan.deviceLimit) + 1;
             for (let j = 0; j < deviceCount; j++) {
                devicesToCreate.push({
                    licenseId: license.id, computerId: uuidv4(), name: `WORKSTATION-${license.key.substring(0, 4)}-${j}`,
                });
             }
        }
    }
    if (devicesToCreate.length > 0) {
      await prisma.device.createMany({ data: devicesToCreate });
      console.log(`Created ${devicesToCreate.length} devices.`);
    }

    await prisma.activityLog.createMany({
        data: [
            { userId: users[1].id, action: 'create', entityType: 'Product', entityName: products[0].name, details: null },
            { userId: users[2].id, action: 'create', entityType: 'Product', entityName: products[1].name, details: null },
        ]
    });
    console.log(`Created 2 activity logs.`);

    console.log(`Seeding finished.`);
}

main()
    .catch(async (e) => {
        console.error(e);
        await prisma.$disconnect();
        exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });