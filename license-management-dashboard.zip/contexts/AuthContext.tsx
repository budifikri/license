import React, { createContext, useContext, useState, useEffect } from 'react';
import type { User } from '../types';
import { useUsers, useCompanies } from '../hooks/useMockData';

interface AuthContextType {
  user: User | null;
  login: (email: string, pass: string) => Promise<void>;
  register: (name: string, email: string, pass: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { data: allUsers, isLoading: usersLoading, addItem: addUser } = useUsers();
  const { data: allCompanies } = useCompanies();

  useEffect(() => {
    // Check for a logged-in user in local storage on initial load
    try {
      const storedUser = localStorage.getItem('authUser');
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      }
    } catch (error) {
      console.error("Failed to parse user from local storage", error);
      localStorage.removeItem('authUser');
    } finally {
      setIsLoading(false);
    }
  }, []);
  
  const login = async (email: string, pass: string): Promise<void> => {
    // Don't attempt login if user data isn't loaded yet.
    if (usersLoading || !allUsers) {
      throw new Error("User data is not available yet. Please try again in a moment.");
    }
    
    // Hardcoded credentials check
    const foundUser = allUsers.find(u => u.email === email);
    
    // In a real app, you'd check a hashed password. Here we simulate for admin and allow any for others.
    if ((email === 'admin@gmail.com' && pass === 'admin123') || (foundUser && email !== 'admin@gmail.com')) {
      if (foundUser) {
        setUser(foundUser);
        localStorage.setItem('authUser', JSON.stringify(foundUser));
        return;
      }
    }
    throw new Error('Invalid email or password');
  };

  const register = async (name: string, email: string, pass: string): Promise<void> => {
    if (usersLoading || !allUsers || !allCompanies) {
        throw new Error("Data is not available yet. Please try again in a moment.");
    }

    const existingUser = allUsers.find(u => u.email === email);
    if (existingUser) {
        throw new Error("An account with this email already exists.");
    }

    if (allCompanies.length === 0) {
        throw new Error("Cannot register a new user: No companies exist in the system.");
    }

    const newUser: Omit<User, 'id'> = {
        name,
        email,
        // In a real app, you would hash the password here
        role: 'User',
        companyId: allCompanies[0].id, // Assign to the first company by default
        createdAt: new Date().toISOString(),
    };
    
    addUser(newUser);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('authUser');
  };
  
  // While users are loading from the mock hook, the app is effectively in a loading state.
  const effectiveIsLoading = isLoading || usersLoading;


  return (
    <AuthContext.Provider value={{ user, login, register, logout, isLoading: effectiveIsLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};