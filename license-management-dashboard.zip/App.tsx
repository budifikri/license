import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Licenses from './components/Licenses';
import Products from './components/Products';
import Plans from './components/Plans';
import Companies from './components/Companies';
import Users from './components/Users';
import Activity from './components/Activity';
import Invoices from './components/Invoices';
import Settings from './components/Settings';
import Devices from './components/Devices';
import Banks from './components/Banks';
import { KeyRound, Loader2 } from './components/icons';
import BottomNav from './components/BottomNav';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import LoginPage from './components/LoginPage';
import { ThemeProvider } from './contexts/ThemeContext';
import FabMenu from './components/FabMenu';
import Help from './components/Help';

type Page = 'dashboard' | 'licenses' | 'devices' | 'products' | 'plans' | 'companies' | 'users' | 'activity' | 'invoices' | 'settings' | 'banks' | 'help';

const pageRoles: Record<Page, string[]> = {
  dashboard: ['Admin', 'Manager', 'User'],
  licenses: ['Admin', 'Manager', 'User'],
  devices: ['Admin', 'Manager'],
  products: ['Admin', 'Manager', 'User'],
  plans: ['Admin', 'Manager', 'User'],
  companies: ['Admin'],
  users: ['Admin', 'Manager'],
  activity: ['Admin'],
  invoices: ['Admin', 'Manager'],
  settings: ['Admin', 'Manager', 'User'],
  banks: ['Admin'],
  help: ['Admin', 'Manager', 'User'],
};


const AuthenticatedApp: React.FC = () => {
  const [activePage, setActivePage] = useState<Page>('dashboard');
  const { user } = useAuth();

  useEffect(() => {
    if (user && !pageRoles[activePage].includes(user.role)) {
      setActivePage('dashboard');
    }
  }, [user, activePage]);


  const renderContent = () => {
    // Additional check to prevent rendering a page the user shouldn't see
    if (user && !pageRoles[activePage].includes(user.role)) {
      return <Dashboard />;
    }

    switch (activePage) {
      case 'dashboard':
        return <Dashboard />;
      case 'licenses':
        return <Licenses />;
      case 'devices':
        return <Devices />;
      case 'products':
        return <Products />;
      case 'plans':
        return <Plans />;
      case 'companies':
        return <Companies />;
      case 'users':
        return <Users />;
      case 'activity':
        return <Activity />;
      case 'invoices':
        return <Invoices />;
      case 'settings':
        return <Settings />;
      case 'banks':
        return <Banks />;
      case 'help':
        return <Help />;
      default:
        return <div>Select a page</div>;
    }
  };

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
      <Sidebar 
        activePage={activePage} 
        setActivePage={setActivePage}
      />
      <div className="flex flex-col flex-1 w-full">
        {/* Mobile Header */}
        <header className="md:hidden sticky top-0 z-10 flex items-center justify-center h-16 px-4 border-b bg-white dark:bg-gray-800 dark:border-gray-700">
          <div className="flex items-center">
             <KeyRound className="h-7 w-7 text-primary" />
             <h1 className="ml-2 text-lg font-bold">Licenser</h1>
          </div>
        </header>

        <main className="flex-1 p-4 md:p-8 overflow-y-auto pb-20 md:pb-8">
          {renderContent()}
        </main>
      </div>
      <BottomNav activePage={activePage} setActivePage={setActivePage} />
      <FabMenu setActivePage={setActivePage} />
    </div>
  );
};

const AppContent: React.FC = () => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-gray-100 dark:bg-gray-900">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }

  return user ? <AuthenticatedApp /> : <LoginPage />;
};


function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;