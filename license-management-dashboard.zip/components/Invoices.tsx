import React, { useState, useMemo } from 'react';
import { useInvoices, useCompanies, useProducts, usePlans, useActivityLogs, useLicenses, useUsers } from '../hooks/useMockData';
import { useSortableData } from '../hooks/useSortableData';
import { usePagination } from '../hooks/usePagination';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from './ui/Card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/Table';
import Button from './ui/Button';
import Input from './ui/Input';
import Select from './ui/Select';
import { Loader2, ChevronsUpDown, ArrowUp, ArrowDown, Eye, Pencil, Trash2, Check } from './icons';
import InvoiceModal from './InvoiceModal';
import InvoiceViewModal from './InvoiceViewModal';
import ConfirmationDialog from './ConfirmationDialog';
import Pagination from './Pagination';
import type { Invoice, Company, LicenseKey } from '../types';
import { formatDate } from '../utils/date';
import { v4 as uuidv4 } from 'uuid';

type AugmentedInvoice = Invoice & { 
  companyName: string;
};

const Invoices: React.FC = () => {
  const { data: invoices, isLoading: invoicesLoading, addItem, updateItem, deleteItem } = useInvoices();
  const { data: companiesData, isLoading: companiesLoading } = useCompanies();
  const { data: productsData } = useProducts();
  const { data: plansData } = usePlans();
  const { data: allLicenses, addMultipleItems: addLicenses, updateItem: updateLicense } = useLicenses();
  const { data: allUsers } = useUsers();
  const { addItem: addActivityLog } = useActivityLogs();
  const { user } = useAuth();
  const isManagerOrAdmin = user?.role === 'Admin' || user?.role === 'Manager';

  const [isModalOpen, setModalOpen] = useState(false);
  const [isViewModalOpen, setViewModalOpen] = useState(false);
  const [invoiceToEdit, setInvoiceToEdit] = useState<Invoice | null>(null);
  const [invoiceToView, setInvoiceToView] = useState<AugmentedInvoice | null>(null);
  const [licensesForView, setLicensesForView] = useState<LicenseKey[]>([]);
  const [itemToDeleteId, setItemToDeleteId] = useState<string | null>(null);

  // Filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [companyFilter, setCompanyFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const companyMap = useMemo(() => new Map(companiesData?.map(c => [c.id, c.name])), [companiesData]);

  const augmentedInvoices = useMemo(() => {
    if (!invoices) return [];
    return invoices.map(invoice => ({
        ...invoice,
        companyName: companyMap.get(invoice.companyId) ?? 'Unknown Company',
    }));
  }, [invoices, companyMap]);


  const filteredInvoices = useMemo(() => {
    if (!augmentedInvoices) return [];
    return augmentedInvoices.filter(invoice => {
      const matchesSearch = invoice.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) || invoice.companyName.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCompany = !companyFilter || invoice.companyId === companyFilter;
      const matchesStatus = !statusFilter || invoice.status === statusFilter;
      return matchesSearch && matchesCompany && matchesStatus;
    });
  }, [augmentedInvoices, searchTerm, companyFilter, statusFilter]);
  
  const { items: sortedInvoices, requestSort, sortConfig } = useSortableData<AugmentedInvoice>(filteredInvoices);
  const { paginatedData: paginatedInvoices, ...paginationProps } = usePagination({ data: sortedInvoices, itemsPerPage: 10 });
  
  const getSortIcon = (key: keyof AugmentedInvoice) => {
    if (!sortConfig || sortConfig.key !== key) return <ChevronsUpDown className="h-4 w-4 ml-2 opacity-40" />;
    if (sortConfig.direction === 'ascending') return <ArrowUp className="h-4 w-4 ml-2" />;
    return <ArrowDown className="h-4 w-4 ml-2" />;
  };

  const handleOpenModal = (invoice: Invoice | null = null) => {
    setInvoiceToEdit(invoice);
    setModalOpen(true);
  };
  
  const handleOpenViewModal = (invoice: AugmentedInvoice) => {
    const associatedLicenses = allLicenses.filter(l => l.invoiceId === invoice.id);
    setLicensesForView(associatedLicenses);
    setInvoiceToView(invoice);
    setViewModalOpen(true);
  };

  const handleSave = (invoiceData: Omit<Invoice, 'id'> | Invoice) => {
    const isEditing = 'id' in invoiceData;

    const companyUsers = allUsers.filter(u => u.companyId === invoiceData.companyId);
    
    if (companyUsers.length === 0 && invoiceData.lineItems.some(l => l.quantity > 0)) {
        alert("Cannot create licenses as there are no users in the selected company.");
        return;
    }

    if (isEditing) {
        updateItem(invoiceData);

        const associatedLicenses = allLicenses.filter(l => l.invoiceId === invoiceData.id);
        associatedLicenses.forEach(license => {
            const isExpired = license.expiresAt && new Date(license.expiresAt) < new Date();
            let newStatus: LicenseKey['status'] = 'Inactive';
            if (isExpired) {
                newStatus = 'Expired';
            } else if (invoiceData.status === 'Paid') {
                newStatus = 'Active';
            }
            if (license.status !== newStatus) {
                updateLicense({ ...license, status: newStatus });
            }
        });

        if(user) {
            addActivityLog({
                userId: user.id, action: 'update', entityType: 'Invoice',
                entityName: invoiceData.invoiceNumber, createdAt: new Date().toISOString(),
            });
        }
    } else {
        const newInvoice = { ...invoiceData, id: uuidv4(), invoiceNumber: `INV-${Date.now().toString().slice(-6)}`};
        const newLicensesToCreate: LicenseKey[] = [];

        newInvoice.lineItems.forEach(item => {
            const plan = plansData.find(p => p.id === item.planId);
            if (plan) {
                for (let i = 0; i < item.quantity; i++) {
                    const expiresAtDate = plan.durationDays > 0 ? new Date(new Date(newInvoice.issueDate).getTime() + plan.durationDays * 24 * 60 * 60 * 1000) : null;
                    const isExpired = expiresAtDate ? expiresAtDate < new Date() : false;
                    let status: LicenseKey['status'] = 'Inactive';
                    if (isExpired) {
                        status = 'Expired';
                    } else if (newInvoice.status === 'Paid') {
                        status = 'Active';
                    }

                    newLicensesToCreate.push({
                        id: uuidv4(), key: uuidv4().toUpperCase(), productId: plan.productId, planId: plan.id,
                        userId: companyUsers[0].id, status: status,
                        expiresAt: expiresAtDate ? expiresAtDate.toISOString() : null,
                        createdAt: new Date(newInvoice.issueDate).toISOString(), invoiceId: newInvoice.id,
                    });
                }
            }
        });

        addItem(newInvoice);
        if (newLicensesToCreate.length > 0) {
            addLicenses(newLicensesToCreate);
        }
        
        if(user) {
            addActivityLog({
                userId: user.id, action: 'create', entityType: 'Invoice',
                entityName: newInvoice.invoiceNumber, createdAt: new Date().toISOString(),
            });
        }
    }
    
    setModalOpen(false);
    setInvoiceToEdit(null);
  };

  const handleMarkAsPaid = (invoice: Invoice) => {
    const updatedInvoice = { ...invoice, status: 'Paid' as const };
    updateItem(updatedInvoice);

    const associatedLicenses = allLicenses.filter(l => l.invoiceId === invoice.id);
    associatedLicenses.forEach(license => {
        const isExpired = license.expiresAt && new Date(license.expiresAt) < new Date();
        const newStatus = isExpired ? 'Expired' : 'Active';
        if (license.status !== newStatus) {
            updateLicense({ ...license, status: newStatus });
        }
    });

     if(user) {
        addActivityLog({
          userId: user.id, action: 'update', entityType: 'Invoice',
          entityName: invoice.invoiceNumber, createdAt: new Date().toISOString(),
          details: { field: 'Status', from: invoice.status, to: 'Paid' }
        });
      }
  };
  
  const handleDelete = (id: string) => {
    const invoiceToDelete = invoices?.find(i => i.id === id);
    deleteItem(id);
    if(invoiceToDelete && user) {
        addActivityLog({
          userId: user.id, action: 'delete', entityType: 'Invoice',
          entityName: invoiceToDelete.invoiceNumber, createdAt: new Date().toISOString(),
        });
    }
    setItemToDeleteId(null);
  };
  
  const formatCurrency = (amount: number) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(amount);
  
  const isLoading = invoicesLoading || companiesLoading;

  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Invoices</h1>
        {isManagerOrAdmin && <Button onClick={() => handleOpenModal()}>Create Invoice</Button>}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Manage Invoices</CardTitle>
          <CardDescription>View, create, and manage all client invoices.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-2 mb-4">
            <Input
              placeholder="Search by invoice # or company..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full sm:max-w-sm"
            />
            <Select value={companyFilter} onChange={(e) => setCompanyFilter(e.target.value)} className="w-full sm:w-auto">
              <option value="">All Companies</option>
              {companiesData?.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
             <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="w-full sm:w-auto">
              <option value="">All Statuses</option>
              <option value="Paid">Paid</option>
              <option value="Unpaid">Unpaid</option>
              <option value="Overdue">Overdue</option>
            </Select>
          </div>
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead><Button variant="ghost" onClick={() => requestSort('invoiceNumber')}>Invoice # {getSortIcon('invoiceNumber')}</Button></TableHead>
                  <TableHead><Button variant="ghost" onClick={() => requestSort('companyName')}>Company {getSortIcon('companyName')}</Button></TableHead>
                  <TableHead><Button variant="ghost" onClick={() => requestSort('dueDate')}>Due Date {getSortIcon('dueDate')}</Button></TableHead>
                  <TableHead><Button variant="ghost" onClick={() => requestSort('total')}>Total {getSortIcon('total')}</Button></TableHead>
                  <TableHead><Button variant="ghost" onClick={() => requestSort('status')}>Status {getSortIcon('status')}</Button></TableHead>
                  {isManagerOrAdmin && <TableHead>Actions</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedInvoices.length > 0 ? paginatedInvoices.map((invoice) => (
                  <TableRow key={invoice.id}>
                    <TableCell className="font-medium">{invoice.invoiceNumber}</TableCell>
                    <TableCell>{invoice.companyName}</TableCell>
                    <TableCell>{formatDate(invoice.dueDate)}</TableCell>
                    <TableCell>{formatCurrency(invoice.total)}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                        invoice.status === 'Paid' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' :
                        invoice.status === 'Overdue' ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200' :
                        'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                      }`}>
                        {invoice.status}
                      </span>
                    </TableCell>
                    {isManagerOrAdmin && (
                      <TableCell>
                        <div className="flex items-center space-x-1">
                          <Button variant="ghost" size="icon" onClick={() => handleOpenViewModal(invoice)} title="View Invoice"><Eye className="h-4 w-4" /></Button>
                          {invoice.status !== 'Paid' && (
                            <Button variant="ghost" size="icon" onClick={() => handleMarkAsPaid(invoice)} title="Mark as Paid"><Check className="h-4 w-4 text-green-600" /></Button>
                          )}
                          <Button variant="ghost" size="icon" onClick={() => handleOpenModal(invoice)} title="Edit Invoice"><Pencil className="h-4 w-4" /></Button>
                          <Button variant="ghost" size="icon" onClick={() => setItemToDeleteId(invoice.id)} title="Delete Invoice"><Trash2 className="h-4 w-4 text-destructive" /></Button>
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                )) : (
                  <TableRow>
                    <TableCell colSpan={isManagerOrAdmin ? 6 : 5} className="text-center">No invoices found.</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
        <CardFooter>
            <Pagination {...paginationProps} />
        </CardFooter>
      </Card>
      
      <InvoiceModal
        isOpen={isModalOpen}
        onClose={() => setModalOpen(false)}
        onSave={handleSave}
        invoiceToEdit={invoiceToEdit}
        companies={companiesData || []}
        plans={plansData || []}
        products={productsData || []}
      />
      <InvoiceViewModal
        isOpen={isViewModalOpen}
        onClose={() => setViewModalOpen(false)}
        invoice={invoiceToView}
        company={companiesData?.find(c => c.id === invoiceToView?.companyId) ?? null}
        licenses={licensesForView}
      />
       <ConfirmationDialog
        isOpen={!!itemToDeleteId}
        onClose={() => setItemToDeleteId(null)}
        onConfirm={() => itemToDeleteId && handleDelete(itemToDeleteId)}
        title="Delete Invoice"
        description="Are you sure you want to delete this invoice? This action cannot be undone."
      />
    </>
  );
};

export default Invoices;